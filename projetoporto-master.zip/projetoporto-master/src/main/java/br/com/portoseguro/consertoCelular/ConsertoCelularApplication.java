package br.com.portoseguro.consertoCelular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsertoCelularApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsertoCelularApplication.class, args);
	}

}
