package br.com.portoseguro.consertoCelular.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EnderecoRequestDTO {
	
	private String cep;
	private String rua;


}
